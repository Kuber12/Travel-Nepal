# Travel Nepal — 3D

A three.js version of **Travel Nepal**, the reality travel adventure board game by
Vajra Portal Pvt. Ltd. Hot-seat for now: two to four travelers share one device.

```bash
npm install
npm run dev
```

Then open http://localhost:5173.

| URL parameter | Effect |
| --- | --- |
| `?seed=42` | Replay an identical game. Same seed ⇒ same dice, same shuffles. |
| `?players=4` | Two to four travelers (default 2). |
| `?auto=1` | The travelers play themselves — a demo, and a flow smoke-test. |

Space bar triggers whatever the current primary action is. Drag to orbit, scroll
to zoom. At a junction, click a glowing tile or use the buttons in the panel.

## What's built

The **full printed board**: 174 tiles traced square-by-square off a photo of the
cardboard original, in the same places. The main road (107 tiles) runs out of
Tribhuvan International Airport through Nepal Mandal and its red ticket lane,
down to Chitwan, west through Lumbini, up into Pokhara and round the lake,
through the Himalayan villages, across the top and back down the Kathmandu road
to Departure. Four gated trips hang off junctions on that road — the
**Eastern Trip**, **Western Terai Trip**, **Western Hillside Trip** and
**Mountain Expedition** — each behind its printed IN arrow. Every section has
its own card deck.

Implemented from the printed rules:

- **Checkpoints** are hard stops. Whatever you rolled, you stop, and you play a
  mini-game for an entry ticket.
- **Ticket counters** sell an entry ticket for a deeper trip.
- **Junctions** hand you the ticket outright if you stop on one, then you choose
  a road. Sub-sections are gated: no ticket, no entry.
- **Cards** are drawn from the deck of the section you stopped in. Collectables
  (Photograph, Souvenir) score; Moments (Travel & Tour, Get Together, 1v1, 2v2)
  come with a mini-game; Wild cards apply an effect and never enter the passport.
- **Wild effects**: Hire a Bike (five single-die rolls), Home Sick / Duty Call
  (ten steps forward), Extend Vacation (ten steps back).
- **Scoring**: passport points, ties broken by number of cards.

## Layout

```
src/
  engine/     the rules — pure, deterministic, no three.js, no DOM
  data/       the board graph and the card decks, as JSON
  render/     three.js: board, pawns, dice, scenery, camera
  ui/         the side panel, the card overlay, the final scoreboard
  main.ts     wiring, and the single dispatch chokepoint
```

**`src/engine/` must never import three.js.** It is a pure reducer over a seeded
RNG: `applyAction(state, action) -> state`. The renderer reads that state and
draws it; animations never decide anything, they only play out a result the
reducer has already committed to.

That boundary is what makes multiplayer a later change rather than a rewrite —
every mutation is already a serializable `Action`, every random draw already goes
through a seeded stream stored in state, and `main.ts` routes everything through
one `dispatch()`. Put the reducer on a server and send actions over a socket.

## Changing the board

`src/data/board.full.json` is generated — don't hand-edit it. The tile
positions live in `tools/gen_board.py` as pixel coordinates on the board photo
(x right, y down), so the 3D board keeps the printed geography:

```bash
python3 tools/gen_board.py src/data/board.full.json            # regenerate
python3 tools/gen_board.py out.json board-photo.png preview.png # + overlay check
```

A node is `{ id, section, kind, next[], pos[x,y,z] }`, plus `requiresTicket`
on the first tile of a gated trip and `ticketReward` on checkpoints and on the
red ticket squares (each sells the trip printed on it). Decks are in
`src/data/decks/` (`tools/gen_decks.py` writes the six newer ones), registered in
`DECK_FILES` in `src/main.ts` and `src/engine/sim.ts`. Scenery in
`src/render/scenery.ts` uses the same photo coordinates. The old slice is kept
as `src/data/board.vertical-slice.json`.

## Checking it

```bash
npm run typecheck   # tsc --noEmit
npm run sim         # 60 headless games, rule invariants + determinism
npm run build       # production bundle
```

`npm run sim` plays whole games with the autoplayer and asserts the things that
would be painful to find by hand: nobody enters a gated section without a ticket,
no move runs through a checkpoint, decks reshuffle instead of running dry,
non-passport cards never reach a passport, and two games from the same seed
produce byte-identical results.

## Not in this version

Bespoke mini-games per card (they all use the dice-off for now) · modelled
(GLTF) temples and mountains · networked multiplayer · sound · save/resume · the Maane spinner as an
alternative to the dice.
