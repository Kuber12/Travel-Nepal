/**
 * Renderer, camera, lights and the render loop. Knows nothing about the rules.
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { SKY_BOTTOM, SKY_TOP } from './palette.ts';

export type Stage = {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  controls: OrbitControls;
  /** Register a per-frame callback. Returns an unsubscribe function. */
  onFrame(fn: (dt: number) => void): () => void;
  /** Ease the orbit target toward a point over the next few frames. */
  focusOn(point: THREE.Vector3): void;
  /** Pull the camera back far enough to see all of `box`, from the south. */
  frame(box: THREE.Box3): void;
  dispose(): void;
};

/** Vertical gradient backdrop — Himalayan sky into valley haze. */
function skyTexture(): THREE.Texture {
  const canvas = document.createElement('canvas');
  canvas.width = 2;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0, `#${SKY_TOP.toString(16).padStart(6, '0')}`);
  grad.addColorStop(1, `#${SKY_BOTTOM.toString(16).padStart(6, '0')}`);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 2, 256);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.mapping = THREE.EquirectangularReflectionMapping;
  return texture;
}

export function createStage(container: HTMLElement): Stage {
  const scene = new THREE.Scene();
  scene.background = skyTexture();
  scene.fog = new THREE.Fog(0xdfe8ee, 60, 150);

  const camera = new THREE.PerspectiveCamera(
    45,
    container.clientWidth / container.clientHeight,
    0.1,
    500,
  );
  camera.position.set(-1, 25, -15);

  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  container.appendChild(renderer.domElement);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.minDistance = 12;
  controls.maxDistance = 90;
  // Keep the camera above the board — no peeking from underneath.
  controls.maxPolarAngle = Math.PI * 0.46;
  controls.target.set(0, 0, 11);

  // Morning light from the east, the way the valley actually gets it.
  const sun = new THREE.DirectionalLight(0xfff3dd, 2.4);
  sun.position.set(26, 40, -8);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.near = 1;
  sun.shadow.camera.far = 120;
  const d = 36;
  sun.shadow.camera.left = -d;
  sun.shadow.camera.right = d;
  sun.shadow.camera.top = d;
  sun.shadow.camera.bottom = -d;
  sun.shadow.bias = -0.0008;
  scene.add(sun);
  scene.add(sun.target);
  sun.target.position.set(0, 0, 11);

  scene.add(new THREE.HemisphereLight(0xcfe6f5, 0xd8c8a4, 1.1));
  scene.add(new THREE.AmbientLight(0xffffff, 0.25));

  // --- frame loop ---
  const callbacks = new Set<(dt: number) => void>();

  let focusTarget: THREE.Vector3 | null = null;
  let lastTick = performance.now();
  let lastFrameAt = lastTick;

  /** Largest slice of time any single update sees, so tweens stay stable. */
  const MAX_SUBSTEP = 0.05;

  function advance(dt: number): void {
    if (focusTarget) {
      controls.target.lerp(focusTarget, 1 - Math.pow(0.004, dt));
      if (controls.target.distanceTo(focusTarget) < 0.05) focusTarget = null;
    }
    for (const fn of callbacks) fn(dt);
    controls.update();
  }

  /**
   * Advance by the elapsed wall time, in sub-steps no larger than MAX_SUBSTEP.
   * `budget` caps how much animation one call may catch up on.
   */
  function step(now: number, budget: number): void {
    const elapsed = Math.min((now - lastTick) / 1000, budget);
    lastTick = now;

    let remaining = elapsed;
    while (remaining > 0) {
      const slice = Math.min(remaining, MAX_SUBSTEP);
      advance(slice);
      remaining -= slice;
    }

    renderer.render(scene, camera);
  }

  renderer.setAnimationLoop(() => {
    lastFrameAt = performance.now();
    step(lastFrameAt, MAX_SUBSTEP);
  });

  /**
   * Turn flow is gated on animations finishing, and a browser that withholds
   * frames — a hidden tab, a throttled background window — would otherwise
   * strand a turn mid-move with input locked for as long as it stays hidden.
   * When requestAnimationFrame goes quiet, keep stepping on a timer.
   *
   * Timers are themselves clamped to ~1Hz in a hidden tab, so this catches up
   * on real elapsed time rather than a single frame's worth. Nobody is looking
   * at the animation in that state; what matters is that the turn finishes.
   */
  const FRAME_STALL_MS = 250;
  const CATCH_UP_BUDGET = 2;
  const fallback = window.setInterval(() => {
    const now = performance.now();
    if (now - lastFrameAt < FRAME_STALL_MS) return;
    step(now, CATCH_UP_BUDGET);
  }, 1000 / 30);

  function resize(): void {
    const w = container.clientWidth;
    const h = container.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  }
  window.addEventListener('resize', resize);

  return {
    scene,
    camera,
    renderer,
    controls,
    onFrame(fn) {
      callbacks.add(fn);
      return () => callbacks.delete(fn);
    },
    focusOn(point) {
      focusTarget = point.clone();
    },

    frame(box) {
      const size = box.getSize(new THREE.Vector3());
      const centre = box.getCenter(new THREE.Vector3());

      // Distance that fits the box both vertically and horizontally.
      const vFov = THREE.MathUtils.degToRad(camera.fov);
      const hFov = 2 * Math.atan(Math.tan(vFov / 2) * camera.aspect);
      const distance = Math.max(size.z / 2 / Math.tan(vFov / 2), size.x / 2 / Math.tan(hFov / 2));

      // Looking from the south and above, so the Mountain loop reads as depth.
      const pull = distance * 1.15;
      camera.position.set(centre.x, pull * 0.72, centre.z - pull * 0.78);
      controls.target.copy(centre);
      controls.maxDistance = pull * 2.2;
      controls.update();

      sun.position.set(centre.x + 26, pull * 1.1, centre.z - 10);
      sun.target.position.copy(centre);
      sun.target.updateMatrixWorld();
    },
    dispose() {
      renderer.setAnimationLoop(null);
      window.clearInterval(fallback);
      window.removeEventListener('resize', resize);
      controls.dispose();
      renderer.dispose();
      container.removeChild(renderer.domElement);
    },
  };
}
