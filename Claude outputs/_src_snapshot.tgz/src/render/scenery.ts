/**
 * The 3D placeables for every region of the printed board: stupas and pagodas
 * in Nepal Mandal, sal forest and a rhino in Chitwan, Phewa Lake in Pokhara,
 * the Maya Devi Temple in Lumbini, tea terraces in the east, an elephant in
 * the Western Terai, village houses in the hills, and the massif inside the
 * Mountain Expedition loop — plus the tinted picture panels and name plates.
 *
 * Everything is built from primitives. Positions are authored in the photo's
 * pixel space (see tools/gen_board.py) so props sit where the printed
 * pictures are.
 */

import * as THREE from 'three';
import type { Board } from '../engine/types.ts';

const BOARD_Y = 0.4;

function mat(color: number, roughness = 0.8): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({ color, roughness });
}

/** Boudhanath/Swayambhunath: dome, cubic harmika, stepped spire. */
function stupa(scale = 1): THREE.Group {
  const group = new THREE.Group();

  const plinth = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.7, 0.35, 16), mat(0xf4f1e8));
  plinth.position.y = 0.17;

  const dome = new THREE.Mesh(
    new THREE.SphereGeometry(1.2, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2),
    mat(0xfbf8f1, 0.85),
  );
  dome.position.y = 0.33;

  const harmika = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.7, 0.85), mat(0xf5e9c8));
  harmika.position.y = 1.65;

  // The painted eyes that look out over the valley.
  const eyes = new THREE.Mesh(
    new THREE.PlaneGeometry(0.72, 0.3),
    new THREE.MeshStandardMaterial({ color: 0x2a3a6a, roughness: 0.6 }),
  );
  eyes.position.set(0, 1.68, 0.44);

  const spire = new THREE.Mesh(new THREE.ConeGeometry(0.5, 1.5, 13), mat(0xe8b53c, 0.45));
  spire.position.y = 2.72;

  const finial = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10), mat(0xf0cd62, 0.3));
  finial.position.y = 3.6;

  for (const m of [plinth, dome, harmika, spire, finial]) {
    m.castShadow = true;
    m.receiveShadow = true;
  }
  group.add(plinth, dome, harmika, eyes, spire, finial);
  group.scale.setScalar(scale);
  return group;
}

/** A Newar pagoda temple — tiered roofs on a stepped brick plinth. */
function pagoda(tiers = 3, scale = 1): THREE.Group {
  const group = new THREE.Group();

  for (let i = 0; i < 3; i++) {
    const step = new THREE.Mesh(
      new THREE.BoxGeometry(2.6 - i * 0.45, 0.26, 2.6 - i * 0.45),
      mat(0xb5663f, 0.95),
    );
    step.position.y = 0.13 + i * 0.26;
    step.castShadow = true;
    step.receiveShadow = true;
    group.add(step);
  }

  let y = 0.78;
  for (let i = 0; i < tiers; i++) {
    const width = 1.5 - i * 0.3;

    const body = new THREE.Mesh(new THREE.BoxGeometry(width, 0.75, width), mat(0x8e3f2a, 0.9));
    body.position.y = y + 0.37;
    body.castShadow = true;

    const roof = new THREE.Mesh(
      new THREE.ConeGeometry(width * 1.15, 0.5, 4),
      mat(0x3c3a38, 0.7),
    );
    roof.position.y = y + 1.0;
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;

    group.add(body, roof);
    y += 1.0;
  }

  const spire = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.6, 8), mat(0xe8b53c, 0.4));
  spire.position.y = y + 0.3;
  spire.castShadow = true;
  group.add(spire);

  group.scale.setScalar(scale);
  return group;
}

/** A snow-capped peak. Height drives how much snow shows. */
function peak(height: number, radius: number): THREE.Group {
  const group = new THREE.Group();

  const rock = new THREE.Mesh(new THREE.ConeGeometry(radius, height, 7), mat(0x6f7f94, 1));
  rock.position.y = height / 2;
  rock.castShadow = true;
  rock.receiveShadow = true;

  const snowHeight = height * 0.38;
  const snow = new THREE.Mesh(
    new THREE.ConeGeometry(radius * 0.38, snowHeight, 7),
    mat(0xfbfdff, 0.6),
  );
  snow.position.y = height - snowHeight / 2;
  snow.castShadow = true;

  group.add(rock, snow);
  return group;
}

/** Sal tree for the Chitwan lowlands. */
function tree(scale = 1): THREE.Group {
  const group = new THREE.Group();

  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.16, 1.2, 7), mat(0x6b4a2f));
  trunk.position.y = 0.6;
  trunk.castShadow = true;

  for (let i = 0; i < 3; i++) {
    const canopy = new THREE.Mesh(
      new THREE.SphereGeometry(0.55 - i * 0.1, 10, 8),
      mat(0x2f7a3e, 0.95),
    );
    canopy.position.set((i - 1) * 0.3, 1.35 + i * 0.28, (i % 2) * 0.25 - 0.1);
    canopy.castShadow = true;
    group.add(canopy);
  }

  group.add(trunk);
  group.scale.setScalar(scale);
  return group;
}

/** The one-horned rhino, in blocks. */
function rhino(): THREE.Group {
  const group = new THREE.Group();
  const hide = mat(0x8c8f93, 0.95);

  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.42, 0.95, 4, 10), hide);
  body.rotation.z = Math.PI / 2;
  body.position.y = 0.7;
  body.castShadow = true;

  const head = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.42, 0.45), hide);
  head.position.set(0.95, 0.62, 0);
  head.castShadow = true;

  const horn = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.34, 7), mat(0xd8d2c4, 0.5));
  horn.position.set(1.28, 0.9, 0);
  horn.rotation.z = -0.3;
  horn.castShadow = true;

  group.add(body, head, horn);
  for (const x of [-0.5, 0.45]) {
    for (const z of [-0.26, 0.26]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.62, 7), hide);
      leg.position.set(x, 0.31, z);
      leg.castShadow = true;
      group.add(leg);
    }
  }
  return group;
}

/** A prayer-wheel "Maane" wall, which also doubles as the spinner's home. */
function prayerWheels(): THREE.Group {
  const group = new THREE.Group();

  const wall = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.9, 0.6), mat(0xd8cdb4, 0.95));
  wall.position.y = 0.45;
  wall.castShadow = true;
  wall.receiveShadow = true;
  group.add(wall);

  for (let i = 0; i < 5; i++) {
    const wheel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.24, 0.42, 14),
      mat(0xc8912f, 0.35),
    );
    wheel.rotation.z = Math.PI / 2;
    wheel.position.set(-1.25 + i * 0.62, 1.1, 0);
    wheel.castShadow = true;
    group.add(wheel);
  }

  const roof = new THREE.Mesh(new THREE.BoxGeometry(3.5, 0.16, 0.95), mat(0x8e3f2a, 0.9));
  roof.position.y = 1.45;
  roof.castShadow = true;
  group.add(roof);

  return group;
}

/** A terraced hillside — the stepped fields of the middle hills. */
function terrace(radius: number, steps = 4): THREE.Group {
  const group = new THREE.Group();
  const greens = [0x7fa64a, 0x8fb355, 0x6f9440, 0x9cbd63];

  for (let i = 0; i < steps; i++) {
    const t = i / steps;
    const ring = new THREE.Mesh(
      new THREE.CylinderGeometry(radius * (1 - t * 0.8), radius * (1 - t * 0.62), 0.17, 16),
      mat(greens[i % greens.length], 1),
    );
    ring.position.y = 0.085 + i * 0.16;
    ring.castShadow = true;
    ring.receiveShadow = true;
    group.add(ring);
  }
  return group;
}

// --- more props for the full board ------------------------------------------

/** A village house: whitewashed walls, a red-ochre lower band, a slate roof. */
function house(scale = 1, roofColor = 0x5a5550): THREE.Group {
  const group = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.7, 0.8), mat(0xf1ece0, 0.9));
  body.position.y = 0.35;
  const band = new THREE.Mesh(new THREE.BoxGeometry(1.02, 0.25, 0.82), mat(0xa8442e, 0.9));
  band.position.y = 0.125;
  const roof = new THREE.Mesh(new THREE.ConeGeometry(0.82, 0.45, 4), mat(roofColor, 0.8));
  roof.position.y = 0.92;
  roof.rotation.y = Math.PI / 4;
  roof.scale.set(1, 1, 0.8);
  for (const m of [body, band, roof]) {
    m.castShadow = true;
    m.receiveShadow = true;
  }
  group.add(body, band, roof);
  group.scale.setScalar(scale);
  return group;
}

/** A Tharu mud hut with a thatched roof. */
function hut(scale = 1): THREE.Group {
  return house(scale, 0xc9a45a);
}

/** Flat water — lakes and rivers. */
function water(width: number, depth: number, color = 0x5fa8c4): THREE.Mesh {
  const mesh = new THREE.Mesh(
    new THREE.PlaneGeometry(width, depth),
    new THREE.MeshStandardMaterial({ color, roughness: 0.2, metalness: 0.1, transparent: true, opacity: 0.9 }),
  );
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = 0.03;
  mesh.receiveShadow = true;
  return mesh;
}

/** A painted doonga — the wooden rowing boats of Phewa Lake. */
function boat(color: number): THREE.Group {
  const group = new THREE.Group();
  const hull = new THREE.Mesh(new THREE.CapsuleGeometry(0.16, 0.8, 4, 8), mat(color, 0.6));
  hull.rotation.z = Math.PI / 2;
  hull.scale.set(1, 1, 0.7);
  hull.position.y = 0.1;
  hull.castShadow = true;
  group.add(hull);
  return group;
}

/** Maya Devi Temple: a white, low, square-walled shrine. */
function whiteTemple(): THREE.Group {
  const group = new THREE.Group();
  const base = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.7, 1.6), mat(0xf7f5ef, 0.9));
  base.position.y = 0.35;
  const top = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.6, 1.0), mat(0xf7f5ef, 0.9));
  top.position.y = 1.0;
  const spire = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.6, 8), mat(0xe8b53c, 0.4));
  spire.position.y = 1.6;
  for (const m of [base, top, spire]) m.castShadow = true;
  group.add(base, top, spire);
  return group;
}

/** The Ashoka pillar, behind its little railing. */
function pillar(): THREE.Group {
  const group = new THREE.Group();
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.15, 2.0, 10), mat(0xc9b48a, 0.8));
  shaft.position.y = 1.0;
  shaft.castShadow = true;
  const fence = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.25, 12, 1, true), mat(0x7a6a50, 0.8));
  fence.position.y = 0.12;
  group.add(shaft, fence);
  return group;
}

/** An Asian elephant, in blocks, for the Western Terai. */
function elephant(): THREE.Group {
  const group = new THREE.Group();
  const hide = mat(0x7d7b7a, 0.95);
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.5, 0.8, 4, 10), hide);
  body.rotation.z = Math.PI / 2;
  body.position.y = 0.95;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.4, 12, 10), hide);
  head.position.set(0.9, 1.15, 0);
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 0.8, 8), hide);
  trunk.position.set(1.15, 0.7, 0);
  trunk.rotation.z = 0.2;
  group.add(body, head, trunk);
  for (const x of [-0.45, 0.45]) {
    for (const z of [-0.25, 0.25]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.6, 8), hide);
      leg.position.set(x, 0.3, z);
      group.add(leg);
    }
  }
  group.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) o.castShadow = true;
  });
  return group;
}

/** A row of clipped tea bushes, as on the Ilam slopes. */
function teaRow(length: number): THREE.Group {
  const group = new THREE.Group();
  const count = Math.max(2, Math.round(length / 0.55));
  for (let i = 0; i < count; i++) {
    const bush = new THREE.Mesh(new THREE.SphereGeometry(0.3, 8, 6), mat(0x3e8d3a, 1));
    bush.scale.set(1, 0.7, 1);
    bush.position.set(-length / 2 + (i * length) / (count - 1), 0.2, 0);
    bush.castShadow = true;
    group.add(bush);
  }
  return group;
}

/** Control tower, terminal and a parked jet for Tribhuvan International. */
function airport(): THREE.Group {
  const group = new THREE.Group();
  const terminal = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.8, 1.2), mat(0xb5402f, 0.8));
  terminal.position.set(0, 0.4, 0.9);
  const tower = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.32, 2.2, 10), mat(0xe8e8e8, 0.6));
  tower.position.set(-1.0, 1.1, 0.9);
  const cab = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.4, 0.45, 10), mat(0x2b5fa8, 0.3));
  cab.position.set(-1.0, 2.4, 0.9);

  const plane = new THREE.Group();
  const fuselage = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 2.0, 4, 10), mat(0xf4f4f4, 0.4));
  fuselage.rotation.z = Math.PI / 2;
  const wing = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.05, 2.4), mat(0xdddddd, 0.4));
  const tail = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.55, 0.05), mat(0xc8102e, 0.5));
  tail.position.set(-1.0, 0.3, 0);
  plane.add(fuselage, wing, tail);
  plane.position.set(0.4, 0.3, -0.7);
  plane.rotation.y = 0.25;

  group.add(terminal, tower, cab, plane);
  group.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });
  return group;
}

/**
 * A printed region panel: the tinted picture area of the board with its name
 * plate, like the photo panels on the cardboard original.
 */
function panel(width: number, depth: number, color: number, label: string): THREE.Group {
  const group = new THREE.Group();
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(width, depth),
    new THREE.MeshStandardMaterial({ color, roughness: 1 }),
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = 0.012;
  ground.receiveShadow = true;
  group.add(ground);

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 96;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = 'rgba(40, 40, 52, 0.88)';
  ctx.beginPath();
  ctx.roundRect(4, 4, 504, 88, 26);
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 5;
  ctx.stroke();
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 46px "Trebuchet MS", Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label.toUpperCase(), 256, 50, 470);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;

  const plateWidth = Math.min(width * 0.85, 6.2);
  const plate = new THREE.Mesh(
    new THREE.PlaneGeometry(plateWidth, plateWidth * (96 / 512)),
    new THREE.MeshBasicMaterial({ map: texture, transparent: true }),
  );
  // Lie flat, readable from the south: the camera looks north (+z) so
  // screen-right is -x; this rotation puts the text the right way round.
  plate.rotation.set(-Math.PI / 2, 0, Math.PI);
  plate.position.set(0, 0.05, -depth / 2 + plateWidth * 0.14);
  group.add(plate);
  return group;
}

/**
 * Board positions are authored in the same pixel space as
 * `tools/gen_board.py` — a photo of the printed board — so a prop sits in the
 * same picture area it occupies on the cardboard original.
 */
const PX = 0.063;
const PX_OX = 680;
const PX_OY = 775;
function px(x: number, y: number): [number, number] {
  return [(PX_OX - x) * PX, (PX_OY - y) * PX];
}

export function buildScenery(_board: Board): THREE.Group {
  const group = new THREE.Group();

  /** Place at photo coordinates. */
  const at = (object: THREE.Object3D, x: number, y: number, rotY = 0): THREE.Object3D => {
    const [wx, wz] = px(x, y);
    object.position.set(wx, BOARD_Y + object.position.y, wz);
    object.rotation.y = rotY;
    group.add(object);
    return object;
  };

  /** A region panel spanning a photo-pixel rectangle. */
  const region = (x0: number, y0: number, x1: number, y1: number, color: number, label: string): void => {
    const g = panel(Math.abs(x1 - x0) * PX, Math.abs(y1 - y0) * PX, color, label);
    at(g, (x0 + x1) / 2, (y0 + y1) / 2);
  };

  // --- picture panels, as printed ---
  region(712, 728, 884, 822, 0xe9b7c4, 'Nepal Mandal');
  region(680, 858, 842, 986, 0x9cc79a, 'Chitwan');
  region(918, 765, 1026, 902, 0xa9d39a, 'Eastern Trip');
  region(328, 798, 505, 866, 0xd9d2c4, 'Lumbini');
  region(372, 942, 600, 1012, 0xb8d79c, 'Western Terai Trip');
  region(334, 592, 438, 722, 0xa8cf8e, 'Western Hillside Trip');
  region(502, 688, 676, 782, 0x9fc9dc, 'Pokhara');
  region(498, 570, 682, 618, 0xc9c1e6, 'Himalayan Village Trip');
  region(758, 548, 994, 624, 0xc8d6ea, 'Mountain Expedition');
  region(930, 650, 1062, 728, 0xe2e0d8, 'Airport');

  const rnd = seeded(90210);

  // --- Nepal Mandal: stupa, pagodas and a prayer-wheel wall ---
  at(stupa(0.75), 752, 770, 0.3);
  at(pagoda(3, 0.7), 812, 762, -0.4);
  at(pagoda(2, 0.55), 856, 790, 0.6);
  at(prayerWheels(), 790, 742, 0).scale.setScalar(0.7);

  // --- Chitwan: sal forest, the Rapti, and a rhino in the grass ---
  at(water(9.6, 1.0), 760, 978);
  for (let i = 0; i < 16; i++) {
    at(tree(0.55 + rnd() * 0.35), 690 + rnd() * 145, 868 + rnd() * 70, rnd() * Math.PI);
  }
  at(rhino(), 770, 952, 2.5).scale.setScalar(0.8);

  // --- Eastern Trip: tea terraces round the hill ---
  at(terrace(2.4, 4), 972, 860, 0.4);
  for (let i = 0; i < 4; i++) at(teaRow(4.2), 972, 786 + i * 15);
  at(house(0.6), 1008, 845, 0.3);

  // --- Lumbini: Maya Devi Temple, the Ashoka pillar, the Peace Pagoda ---
  at(whiteTemple(), 410, 830, 0);
  at(pillar(), 360, 832);
  at(stupa(0.5), 470, 830, 0.2);

  // --- Western Terai: grassland, Tharu huts and an elephant ---
  for (let i = 0; i < 8; i++) at(tree(0.5 + rnd() * 0.3), 385 + rnd() * 200, 950 + rnd() * 18, rnd() * 3);
  at(hut(0.7), 395, 962, 0.4);
  at(hut(0.6), 428, 968, -0.3);
  at(elephant(), 535, 985, 2.8).scale.setScalar(0.75);

  // --- Western Hillside: terraced farmland and a hilltop durbar ---
  at(terrace(1.9, 5), 385, 680, 0.2);
  at(pagoda(2, 0.5), 405, 620, 0.3);
  at(house(0.55), 352, 615, 0.6);
  at(house(0.5), 352, 655, -0.2);

  // --- Pokhara: Phewa Lake, Tal Barahi on its island, painted doongas ---
  at(water(10.0, 4.6), 590, 738);
  const island = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.9, 0.12, 14), mat(0x6f9440, 1));
  island.position.y = 0.06;
  at(island, 600, 735);
  at(pagoda(2, 0.42), 600, 735, 0.2);
  at(boat(0xc8402e), 545, 752, 0.5);
  at(boat(0x2b5fa8), 650, 718, -0.4);
  at(boat(0xe8a435), 560, 712, 1.2);

  // --- Himalayan Village: stone houses below a little ridge ---
  for (const [x, y] of [[520, 600], [548, 590], [600, 598], [632, 588], [660, 602]]) {
    at(house(0.45 + rnd() * 0.1), x, y, rnd() * 0.6 - 0.3);
  }
  at(peak(2.2, 0.9), 575, 582);

  // --- Mountain Expedition: the massif inside its loop ---
  for (const [x, y, h, r] of [
    [875, 578, 5.0, 2.0],
    [815, 580, 3.4, 1.4],
    [935, 580, 3.6, 1.4],
    [780, 575, 2.4, 1.0],
    [972, 578, 2.2, 0.9],
  ]) {
    at(peak(h, r), x, y);
  }

  // --- Tribhuvan International ---
  at(airport(), 1000, 672, 0);

  // --- the Himalaya along the far edge, a backdrop beyond the board ---
  for (let i = 0; i < 14; i++) {
    const x = 260 + i * 62 + rnd() * 20;
    const h = 7 + rnd() * 7;
    const g = peak(h, 3 + rnd() * 1.5);
    const [wx, wz] = px(x, 395 - rnd() * 40);
    g.position.set(wx, 0, wz);
    group.add(g);
  }

  return group;
}

/** Tiny local PRNG so scenery scatter is identical on every page load. */
function seeded(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}
