/**
 * Traveler pawns — the four standees from the box, as tapered 3D wedges — and
 * the hop animation that walks one along a path of board nodes.
 */

import * as THREE from 'three';
import type { Player } from '../engine/types.ts';
import type { BoardView } from './board3d.ts';

/** Seconds per node hop. */
const HOP_TIME = 0.22;
const HOP_HEIGHT = 0.9;

export type PawnView = {
  group: THREE.Group;
  /** Snap a pawn to a node with no animation. */
  place(playerId: number, nodeId: string): void;
  /**
   * Hop a pawn along `path`. Resolves once it lands on the final node.
   * Several pawns on one tile are fanned out so none is hidden.
   */
  move(playerId: number, path: string[]): Promise<void>;
  setActive(playerId: number): void;
  update(dt: number): void;
};

function buildPawn(color: string): THREE.Group {
  const group = new THREE.Group();
  const material = new THREE.MeshStandardMaterial({
    color: new THREE.Color(color),
    roughness: 0.45,
    metalness: 0.05,
  });

  // The standee: a four-sided tapered wedge, like the printed card stands.
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.44, 1.15, 4), material);
  body.position.y = 0.575;
  body.rotation.y = Math.PI / 4;
  body.castShadow = true;

  // A pale head so the traveler reads as a person from above.
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.22, 16, 12),
    new THREE.MeshStandardMaterial({ color: 0xf2dcc0, roughness: 0.6 }),
  );
  head.position.y = 1.3;
  head.castShadow = true;

  // A backpack, so you can tell front from back as the camera orbits.
  const pack = new THREE.Mesh(
    new THREE.BoxGeometry(0.34, 0.42, 0.22),
    new THREE.MeshStandardMaterial({ color: 0x4a4a4a, roughness: 0.8 }),
  );
  pack.position.set(0, 0.78, -0.3);
  pack.castShadow = true;

  group.add(body, head, pack);
  return group;
}

/** Spread pawns sharing a tile around a small circle. */
function fanOffset(index: number, total: number): THREE.Vector3 {
  if (total <= 1) return new THREE.Vector3();
  const angle = (index / total) * Math.PI * 2;
  const radius = 0.34;
  return new THREE.Vector3(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
}

export function buildPawns(players: Player[], board: BoardView): PawnView {
  const group = new THREE.Group();
  const meshes = new Map<number, THREE.Group>();
  /** Where each pawn currently stands, used to fan out shared tiles. */
  const standingOn = new Map<number, string>();

  for (const player of players) {
    const pawn = buildPawn(player.color);
    group.add(pawn);
    meshes.set(player.id, pawn);
  }

  let activeId = players[0]?.id ?? 0;
  let bob = 0;

  /** Pawns mid-hop; their Y is owned by the tween, not by the idle bob. */
  const moving = new Set<number>();

  /** Re-fan every pawn so co-located travelers stay visible. */
  function restack(): void {
    const byNode = new Map<string, number[]>();
    for (const [id, nodeId] of standingOn) {
      const list = byNode.get(nodeId) ?? [];
      list.push(id);
      byNode.set(nodeId, list);
    }
    for (const [nodeId, ids] of byNode) {
      ids.sort((a, b) => a - b);
      const base = board.standPos(nodeId);
      ids.forEach((id, i) => {
        const mesh = meshes.get(id);
        if (!mesh || moving.has(id)) return;
        mesh.position.copy(base).add(fanOffset(i, ids.length));
      });
    }
  }

  type Tween = {
    playerId: number;
    from: THREE.Vector3;
    to: THREE.Vector3;
    elapsed: number;
    resolve: () => void;
  };
  let tweens: Tween[] = [];

  function hop(playerId: number, toNodeId: string): Promise<void> {
    const mesh = meshes.get(playerId);
    if (!mesh) return Promise.resolve();
    return new Promise((resolve) => {
      tweens.push({
        playerId,
        from: mesh.position.clone(),
        to: board.standPos(toNodeId),
        elapsed: 0,
        resolve,
      });
    });
  }

  return {
    group,

    place(playerId, nodeId) {
      standingOn.set(playerId, nodeId);
      const mesh = meshes.get(playerId);
      if (mesh) mesh.position.copy(board.standPos(nodeId));
      restack();
    },

    async move(playerId, path) {
      if (path.length === 0) return;
      moving.add(playerId);
      for (const nodeId of path) {
        await hop(playerId, nodeId);
        standingOn.set(playerId, nodeId);
      }
      moving.delete(playerId);
      restack();
    },

    setActive(playerId) {
      activeId = playerId;
    },

    update(dt) {
      bob += dt * 2.5;

      // Gentle idle bob on the traveler whose turn it is.
      for (const [id, mesh] of meshes) {
        mesh.scale.setScalar(id === activeId ? 1.08 : 1);

        const nodeId = standingOn.get(id);
        if (moving.has(id) || !nodeId) continue; // the tween owns Y while hopping

        const lift = id === activeId ? Math.sin(bob) * 0.06 + 0.06 : 0;
        mesh.position.y = board.standPos(nodeId).y + lift;
      }

      if (tweens.length === 0) return;

      const done: Tween[] = [];
      for (const tween of tweens) {
        tween.elapsed += dt;
        const t = Math.min(tween.elapsed / HOP_TIME, 1);
        const mesh = meshes.get(tween.playerId);
        if (mesh) {
          mesh.position.lerpVectors(tween.from, tween.to, t);
          // A parabola over the gap — the pawn hops rather than slides.
          mesh.position.y += Math.sin(t * Math.PI) * HOP_HEIGHT;
          if (t < 1) {
            mesh.rotation.y = Math.atan2(
              tween.to.x - tween.from.x,
              tween.to.z - tween.from.z,
            );
          }
        }
        if (t >= 1) done.push(tween);
      }

      if (done.length > 0) {
        tweens = tweens.filter((t) => !done.includes(t));
        for (const tween of done) tween.resolve();
      }
    },
  };
}
