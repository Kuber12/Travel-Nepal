/**
 * The side panel: whose turn it is, what they can do now, the scoreboard from
 * the box lid, and a running travel log.
 */

import { nodeAt } from '../engine/board.ts';
import { counterOffer } from '../engine/autoplay.ts';
import { current, scoreFor } from '../engine/reducer.ts';
import type { Action, GameState } from '../engine/types.ts';
import { SECTION_LABEL } from '../render/palette.ts';

export type Hud = {
  render(state: GameState, busy: boolean): void;
};

/** What the primary button says and does, per phase. */
function primaryFor(state: GameState): { label: string; action: Action } | null {
  switch (state.phase) {
    case 'await-roll':
      return { label: current(state).singleDieTurns > 0 ? 'Roll one die' : 'Roll the dice', action: { type: 'ROLL' } };
    case 'checkpoint-minigame':
      return { label: 'Play for a ticket', action: { type: 'PLAY_MINIGAME' } };
    case 'card-minigame':
      return { label: 'Play the mini-game', action: { type: 'PLAY_MINIGAME' } };
    case 'await-draw':
      return { label: 'Draw a card', action: { type: 'DRAW_CARD' } };
    case 'end-turn':
      return { label: 'End turn', action: { type: 'END_TURN' } };
    default:
      return null;
  }
}

function promptFor(state: GameState): string {
  const player = current(state);
  const node = nodeAt(state.board, player.nodeId);
  const where = node.label ?? SECTION_LABEL[node.section];

  switch (state.phase) {
    case 'await-roll':
      return player.singleDieTurns > 0
        ? `At ${where}. On a hired bike — one die for ${player.singleDieTurns} more turn(s).`
        : `At ${where}. Roll to travel on.`;
    case 'moving':
      return 'Travelling…';
    case 'await-branch':
      return 'The road splits. Choose which way to go — click a glowing tile or a button below.';
    case 'ticket-counter':
      return 'Ticket Counter. Buy an entry ticket here for a deeper trip, or travel on.';
    case 'checkpoint-minigame':
      return `${where} — everyone stops here, whatever they rolled. Win the mini-game to earn an entry ticket.`;
    case 'await-draw':
      return `Stopped in ${SECTION_LABEL[node.section]}. Draw from this section's deck.`;
    case 'card-minigame':
      return 'This card comes with a mini-game. Play it to collect the points.';
    case 'resolve-card':
      return 'Read the card, then add it to your passport.';
    case 'end-turn':
      return 'Turn complete.';
    case 'game-over':
      return 'Every traveler has flown home.';
    default:
      return '';
  }
}

export function createHud(root: HTMLElement, dispatch: (action: Action) => void): Hud {
  return {
    render(state, busy) {
      const active = current(state);
      const primary = primaryFor(state);

      root.replaceChildren();

      // --- whose turn ---
      const turn = el('div', 'hud-turn');
      turn.append(
        swatch(active.color),
        text(`${active.name} · turn ${state.turn}`),
      );
      root.append(turn);

      root.append(el('div', 'hud-prompt', promptFor(state)));

      // --- actions ---
      const actions = el('div', 'hud-actions');

      if (primary) {
        actions.append(button(primary.label, () => dispatch(primary.action), busy));
      }

      if (state.phase === 'await-branch') {
        for (const nodeId of state.branchOptions) {
          const node = nodeAt(state.board, nodeId);
          const gate = node.requiresTicket;
          const locked = Boolean(gate) && !active.tickets.includes(gate!);
          const label = node.label ?? SECTION_LABEL[node.section];
          actions.append(
            button(
              locked ? `${label} 🔒` : label,
              () => dispatch({ type: 'CHOOSE_BRANCH', nodeId }),
              busy || locked,
              'ghost',
            ),
          );
        }
      }

      if (state.phase === 'ticket-counter') {
        const offer = counterOffer(state);
        if (offer) {
          actions.append(
            button(`Buy ${SECTION_LABEL[offer]} ticket`, () =>
              dispatch({ type: 'CLAIM_COUNTER_TICKET', section: offer }), busy),
          );
        }
        actions.append(
          button('Travel on', () => dispatch({ type: 'SKIP_COUNTER' }), busy, 'ghost'),
        );
      }

      if (actions.childElementCount > 0) root.append(actions);

      // --- scoreboard ---
      root.append(el('p', 'section-title', 'Scoreboard'));
      const players = el('div', 'players');

      for (const player of state.players) {
        const row = el('div', `player${player.id === active.id ? ' active' : ''}`);

        const names = el('div');
        names.append(el('span', 'name', player.name));

        const bits: string[] = [`${player.passport.length} card(s)`];
        if (player.tickets.length > 0) {
          bits.push(`🎫 ${player.tickets.map((t) => SECTION_LABEL[t]).join(', ')}`);
        }
        if (player.singleDieTurns > 0) bits.push(`🚲 ${player.singleDieTurns}`);
        if (player.finished) bits.push('flown home');
        names.append(el('span', 'meta', bits.join(' · ')));

        row.append(swatch(player.color), names, el('span', 'score', String(scoreFor(state, player))));
        players.append(row);
      }
      root.append(players);

      // --- log, newest first ---
      const log = el('div', 'log');
      for (const entry of state.log.slice(-40)) {
        const line = el('div');
        const who = state.players.find((p) => p.id === entry.playerId);
        line.append(el('b', '', `${who?.name ?? '?'}: `), text(entry.text));
        log.append(line);
      }
      root.append(log);
    },
  };
}

// --- tiny DOM helpers --------------------------------------------------------

function el(tag: string, className = '', content = ''): HTMLElement {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (content) node.textContent = content;
  return node;
}

function text(value: string): Text {
  return document.createTextNode(value);
}

function swatch(color: string): HTMLElement {
  const node = el('span', 'swatch');
  node.style.background = color;
  return node;
}

function button(
  label: string,
  onClick: () => void,
  disabled = false,
  variant = '',
): HTMLButtonElement {
  const node = document.createElement('button');
  node.textContent = label;
  node.disabled = disabled;
  if (variant) node.className = variant;
  node.addEventListener('click', onClick);
  return node;
}
