/**
 * The drawn card, and the end-of-game scoreboard, as overlays.
 */

import { scoreFor } from '../engine/reducer.ts';
import type { Action, Card, CardCategory, GameState } from '../engine/types.ts';
import { SECTION_COLOR, SECTION_LABEL } from '../render/palette.ts';

const CATEGORY_LABEL: Record<CardCategory, string> = {
  photograph: 'Photograph',
  souvenir: 'Souvenir',
  'travel-tour': 'Travel & Tour',
  'get-together': 'Get Together',
  'duel-1v1': 'One on One Dual',
  'duel-2v2': 'Two on Two Dual',
  wild: 'Wild Card',
};

export type Overlay = {
  render(state: GameState, busy: boolean): void;
};

function hex(color: number): string {
  return `#${color.toString(16).padStart(6, '0')}`;
}

export function createOverlay(root: HTMLElement, dispatch: (action: Action) => void): Overlay {
  return {
    render(state, busy) {
      if (state.phase === 'game-over') {
        root.replaceChildren(scoreboard(state));
        root.classList.add('open');
        return;
      }

      const cardId = state.drawnCardId;
      const showing = cardId && (state.phase === 'resolve-card' || state.phase === 'card-minigame');

      if (!showing) {
        root.classList.remove('open');
        root.replaceChildren();
        return;
      }

      root.replaceChildren(cardFace(state, state.cards[cardId], busy, dispatch));
      root.classList.add('open');
    },
  };
}

function cardFace(
  state: GameState,
  card: Card,
  busy: boolean,
  dispatch: (action: Action) => void,
): HTMLElement {
  const wrap = document.createElement('div');
  wrap.className = 'card';

  const accent = card.deck === 'wild' ? 0x6b4f9e : SECTION_COLOR[card.deck];

  const head = document.createElement('div');
  head.className = 'card-head';
  head.style.background = hex(accent);

  const kind = document.createElement('div');
  kind.append(
    tag('div', 'card-kind', CATEGORY_LABEL[card.category]),
    tag('div', '', card.deck === 'wild' ? 'Wild' : SECTION_LABEL[card.deck]),
  );

  const points = document.createElement('div');
  points.className = 'card-points';
  if (card.points > 0) {
    points.textContent = String(card.points);
    points.append(tag('small', '', 'POINTS'));
  }

  head.append(kind, points);

  const body = document.createElement('div');
  body.className = 'card-body';
  body.append(tag('h2', '', card.title), tag('p', '', card.blurb));

  if (state.minigameWon !== null && state.phase === 'resolve-card') {
    body.append(
      tag('div', `card-result ${state.minigameWon ? 'win' : 'lose'}`, minigameText(state)),
    );
  }

  const foot = document.createElement('div');
  foot.className = 'card-foot';

  if (state.phase === 'card-minigame') {
    foot.append(
      actionButton('Play the mini-game', () => dispatch({ type: 'PLAY_MINIGAME' }), busy),
    );
  } else {
    foot.append(
      actionButton(
        card.effect ? 'Apply the card' : 'Into the passport',
        () => dispatch({ type: 'RESOLVE_CARD' }),
        busy,
      ),
    );
  }

  wrap.append(head, body, foot);
  return wrap;
}

/** How the mini-game went, phrased for whichever kind it was. */
function minigameText(state: GameState): string {
  const total = state.minigameRoll?.total ?? 0;
  const spec = state.pendingMinigame?.spec;

  if (spec?.type === 'feast') {
    return 'Everyone at the table collects this one.';
  }

  if (state.minigameRivals.length > 0) {
    const scores = state.minigameRivals
      .map((r) => `${state.players.find((p) => p.id === r.playerId)?.name ?? '?'} rolled ${r.total}`)
      .join(', ');
    return state.minigameWon
      ? `You rolled ${total}; ${scores}. The card is yours.`
      : `You rolled ${total}; ${scores}. Beaten this time.`;
  }

  const target = spec?.target;
  return state.minigameWon
    ? `Won it — rolled ${total}${target ? ` against ${target}` : ''}. The card is yours.`
    : `Rolled ${total}${target ? `, needed ${target}` : ''}. No points this time.`;
}

function scoreboard(state: GameState): HTMLElement {
  const wrap = document.createElement('div');
  wrap.className = 'scoreboard';

  const ranked = [...state.players].sort(
    (a, b) => scoreFor(state, b) - scoreFor(state, a) || b.passport.length - a.passport.length,
  );

  wrap.append(
    tag('h2', '', 'Vacation over'),
    tag('p', '', 'Scores from the passport, highest first. Ties go to the bigger collection.'),
  );

  const table = document.createElement('table');
  const head = document.createElement('tr');
  for (const label of ['Traveler', 'Cards', 'Tickets', 'Score']) {
    head.append(tag('th', '', label));
  }
  table.append(head);

  for (const player of ranked) {
    const row = document.createElement('tr');
    if (player.id === state.winnerId) row.className = 'winner';
    row.append(
      tag('td', '', player.id === state.winnerId ? `★ ${player.name}` : player.name),
      tag('td', '', String(player.passport.length)),
      tag('td', '', String(player.tickets.length)),
      tag('td', '', String(scoreFor(state, player))),
    );
    table.append(row);
  }

  wrap.append(table);

  const foot = document.createElement('div');
  foot.className = 'card-foot';
  foot.append(actionButton('New journey', () => window.location.reload(), false));
  wrap.append(foot);

  return wrap;
}

function tag(name: string, className: string, content: string): HTMLElement {
  const node = document.createElement(name);
  if (className) node.className = className;
  node.textContent = content;
  return node;
}

function actionButton(label: string, onClick: () => void, disabled: boolean): HTMLButtonElement {
  const node = document.createElement('button');
  node.textContent = label;
  node.disabled = disabled;
  node.addEventListener('click', onClick);
  return node;
}
