/**
 * Wiring: engine state in, 3D and DOM out, player input back through one
 * `dispatch`. That single chokepoint is where a socket goes when this becomes
 * multiplayer — the rules themselves won't need to change.
 */

import * as THREE from 'three';
import './style.css';

import boardFile from './data/board.full.json' with { type: 'json' };
import nepalmandal from './data/decks/nepalmandal.json' with { type: 'json' };
import chitwan from './data/decks/chitwan.json' with { type: 'json' };
import lumbini from './data/decks/lumbini.json' with { type: 'json' };
import pokhara from './data/decks/pokhara.json' with { type: 'json' };
import himalayan from './data/decks/himalayan.json' with { type: 'json' };
import eastern from './data/decks/eastern.json' with { type: 'json' };
import westernterai from './data/decks/westernterai.json' with { type: 'json' };
import westernhillside from './data/decks/westernhillside.json' with { type: 'json' };
import mountain from './data/decks/mountain.json' with { type: 'json' };
import wild from './data/decks/wild.json' with { type: 'json' };

import type { DeckFile } from './engine/decks.ts';
import { nextAction } from './engine/autoplay.ts';
import { applyAction, current } from './engine/reducer.ts';
import { newGame, type BoardFile } from './engine/setup.ts';
import type { Action, GameState } from './engine/types.ts';

import { buildBoard } from './render/board3d.ts';
import { buildDice } from './render/dice3d.ts';
import { buildPawns } from './render/pawn.ts';
import { buildScenery } from './render/scenery.ts';
import { createStage } from './render/scene.ts';
import { createOverlay } from './ui/cardmodal.ts';
import { createHud } from './ui/hud.ts';

const DECK_FILES = [
  nepalmandal, chitwan, lumbini, pokhara, himalayan, eastern, westernterai, westernhillside, mountain, wild,
] as unknown as DeckFile[];
const BOARD = boardFile as unknown as BoardFile;

/** ?seed=123 replays an identical game — handy for debugging and for demos. */
const params = new URLSearchParams(window.location.search);
const seedParam = params.get('seed');
const playersParam = params.get('players');
/** ?auto=1 lets the travelers play themselves — a demo, and a way to smoke-test the flow. */
const autoPlay = params.get('auto') === '1';

let state: GameState = newGame({
  seed: seedParam ? Number(seedParam) : undefined,
  playerCount: playersParam ? Number(playersParam) : 2,
  boardFile: BOARD,
  deckFiles: DECK_FILES,
});

// --- scene -------------------------------------------------------------------

const stage = createStage(document.getElementById('stage')!);

const board = buildBoard(state.board);
stage.scene.add(board.group);
stage.frame(board.bounds);
stage.scene.add(buildScenery(state.board));

const pawns = buildPawns(state.players, board);
stage.scene.add(pawns.group);

const dice = buildDice();
stage.scene.add(dice.group);

stage.onFrame((dt) => {
  board.update(dt);
  pawns.update(dt);
  dice.update(dt);
});

for (const player of state.players) pawns.place(player.id, player.nodeId);

// --- ui ----------------------------------------------------------------------

const hud = createHud(document.getElementById('hud')!, (action) => void dispatch(action));
const overlay = createOverlay(document.getElementById('overlay')!, (action) => void dispatch(action));

/** True while an animation is playing; input is locked so state can't race it. */
let busy = false;

function render(): void {
  hud.render(state, busy);
  overlay.render(state, busy);

  pawns.setActive(current(state).id);
  board.setHighlight(state.phase === 'await-branch' ? state.branchOptions : []);
}

// --- the dispatch chokepoint -------------------------------------------------

/**
 * Apply an action, then play out whatever the new state implies before giving
 * control back. Animations never decide anything — they only show a result the
 * reducer has already committed to.
 */
async function dispatch(action: Action): Promise<void> {
  if (busy) return;

  const previous = state;
  state = applyAction(state, action);
  if (state === previous) return;

  busy = true;
  render();

  try {
    await playOut(action, previous);
  } finally {
    busy = false;
  }

  render();

  if (autoPlay) {
    const next = nextAction(state);
    if (next) {
      await wait(450);
      void dispatch(next);
    }
  }
}

async function playOut(action: Action, previous: GameState): Promise<void> {
  const mover = current(previous);

  switch (action.type) {
    case 'ROLL': {
      if (state.lastRoll) {
        stage.focusOn(board.worldPos(mover.nodeId));
        await rollDiceBeside(mover.nodeId, state.lastRoll.dice);
      }
      dice.hide();
      await walkPawn(mover.id);
      await finish({ type: 'MOVE_COMPLETE' });
      break;
    }

    case 'CHOOSE_BRANCH': {
      await walkPawn(mover.id);
      await finish({ type: 'MOVE_COMPLETE' });
      break;
    }

    case 'PLAY_MINIGAME': {
      if (state.minigameRoll) {
        await rollDiceBeside(mover.nodeId, state.minigameRoll.dice, 520);
      }
      dice.hide();
      break;
    }

    case 'RESOLVE_CARD': {
      // A wild card may have moved the pawn; play that out, then end the turn.
      if (state.pendingPath.length > 0) {
        await walkPawn(mover.id);
        await finish({ type: 'END_TURN' });
      }
      break;
    }

    default:
      break;
  }
}

/** Throw the dice on the board next to the traveler who is rolling. */
async function rollDiceBeside(nodeId: string, values: number[], linger = 320): Promise<void> {
  const at = board.standPos(nodeId);
  // Offset toward the camera so the dice never land under a pawn or a temple.
  dice.group.position.set(at.x, at.y + 0.9, at.z - 2.6);
  await dice.roll(values);
  await wait(linger);
}

/** Hop the pawn along whatever path the reducer queued, then clear it. */
async function walkPawn(playerId: number): Promise<void> {
  const path = state.pendingPath;
  if (path.length === 0) return;
  stage.focusOn(board.worldPos(path[path.length - 1]));
  await pawns.move(playerId, path);
  await wait(140);
}

/** Continue the chain without re-entering the busy guard. */
async function finish(action: Action): Promise<void> {
  const previous = state;
  state = applyAction(state, action);
  if (state !== previous) {
    render();
    await playOut(action, previous);
  }
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// --- clicking a glowing tile to choose a branch ------------------------------

const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();

stage.renderer.domElement.addEventListener('pointerdown', (event) => {
  if (busy || state.phase !== 'await-branch') return;

  const rect = stage.renderer.domElement.getBoundingClientRect();
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

  raycaster.setFromCamera(pointer, stage.camera);
  const hit = raycaster.intersectObjects(board.pickables(), false)[0];
  const nodeId = hit?.object.userData.nodeId as string | undefined;
  if (nodeId) void dispatch({ type: 'CHOOSE_BRANCH', nodeId });
});

// --- keyboard: space is the primary action ----------------------------------

window.addEventListener('keydown', (event) => {
  if (event.code !== 'Space' || busy) return;
  event.preventDefault();

  switch (state.phase) {
    case 'await-roll':
      void dispatch({ type: 'ROLL' });
      break;
    case 'checkpoint-minigame':
    case 'card-minigame':
      void dispatch({ type: 'PLAY_MINIGAME' });
      break;
    case 'await-draw':
      void dispatch({ type: 'DRAW_CARD' });
      break;
    case 'resolve-card':
      void dispatch({ type: 'RESOLVE_CARD' });
      break;
    case 'end-turn':
      void dispatch({ type: 'END_TURN' });
      break;
    default:
      break;
  }
});

render();

if (autoPlay) {
  const opening = nextAction(state);
  if (opening) void dispatch(opening);
}

/** A read-only snapshot for debugging from the browser console. */
(window as unknown as Record<string, unknown>).travelNepal = () => ({
  phase: state.phase,
  turn: state.turn,
  busy,
  winnerId: state.winnerId,
  players: state.players.map((p) => ({
    name: p.name,
    node: p.nodeId,
    cards: p.passport.length,
    tickets: p.tickets,
    finished: p.finished,
  })),
  log: state.log.slice(-6).map((e) => e.text),
});
