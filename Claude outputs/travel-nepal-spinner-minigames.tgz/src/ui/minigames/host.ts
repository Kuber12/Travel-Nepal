/**
 * Runs a mini-game for the current situation: picks the game that fits the
 * card (or checkpoint), shows the intro, hands the keyboard to each traveler
 * in a duel in turn (hot-seat), then reports the scores as a MinigameResult.
 */

import { current, rivalsFor } from '../../engine/reducer.ts';
import type { Card, GameState, MinigameResult, Player } from '../../engine/types.ts';
import { renderCard } from '../cardview.ts';
import { GAMES, type Difficulty, type GameTheme, type MiniGame } from './games.ts';

type Pick = { game: string; theme?: GameTheme };

/** Which game each card plays — themed to what the card is about. */
const BY_CARD: Record<string, Pick> = {
  // Travel & Tour — played solo against the card's target.
  'nm-tour-guide': { game: 'quiz' },
  'cht-tour-jeepsafari': { game: 'snapshot', theme: { subject: '🦏' } },
  'lum-tour-cycle': { game: 'catch', theme: { good: ['🪷', '🌸'], bad: ['🪨'], catcher: '🚲', title: 'Cycle the Sacred Garden' } },
  'pok-tour-paragliding': { game: 'catch', theme: { good: ['🎈', '☁️'], bad: ['🦅'], catcher: '🪂', title: 'Ride the thermals' } },
  'pok-tour-boating': { game: 'gate', theme: { title: 'Row in time' } },
  'him-tour-homestay': { game: 'match' },
  'eas-tour-teapick': { game: 'catch', theme: { good: ['🍃', '🌿'], bad: ['🐛'], catcher: '🧺', title: 'Pick the two leaves and a bud' } },
  'mtn-tour-sherpaguide': { game: 'climb', theme: { climber: '🧗', goal: '🏔️' } },
  'whl-tour-cave': { game: 'flags', theme: { steps: 'lamps', title: "Follow the guide's lamp" } },
  'wtr-tour-tigertrack': { game: 'snapshot', theme: { subject: '🐅' } },
  'wtr-tour-rafting': { game: 'catch', theme: { good: ['🛟', '⭐'], bad: ['🪨'], catcher: '🚣', title: 'Run the rapids' } },

  // Duels — every player plays the same round; the best score wins.
  'nm-duel-momo': { game: 'catch', theme: { good: ['🥟'], bad: ['🌶️'], catcher: '🍽️' } },
  'cht-duel-birdcount': { game: 'snapshot', theme: { subject: '🦜' } },
  'eas-duel-chhurpi': { game: 'climb', theme: { climber: '😬', goal: '🧀', title: 'Chew, chew, chew!' } },
  'him-duel-teahouse': { game: 'climb', theme: { climber: '🥾', goal: '🍵' } },
  'lum-duel-meditation': { game: 'flags', theme: { steps: 'breaths', title: 'Breathe with the bells' } },
  'mtn-duel-summitrace': { game: 'climb', theme: { climber: '🧗', goal: '🚩' } },
  'whl-duel-ridge': { game: 'gate', theme: { title: 'Keep your footing' } },
  'pok-duel-zipline': { game: 'gate', theme: { title: 'Time the drop' } },
  'wtr-duel-maghi': { game: 'flags', theme: { steps: 'steps', title: 'Follow the dance' } },
};

function pickFor(state: GameState): Pick {
  const pending = state.pendingMinigame!;
  if (pending.source === 'checkpoint') return { game: 'gate' };
  const card = pending.cardId ? state.cards[pending.cardId] : undefined;
  if (card && BY_CARD[card.id]) return BY_CARD[card.id];
  if (card?.category === 'travel-tour') return { game: 'quiz' };
  return { game: 'climb' };
}

/** The card's dice target (4–6) becomes an easy / medium / hard game. */
function difficultyFor(state: GameState): Difficulty {
  const target = state.pendingMinigame?.spec.target ?? 5;
  return Math.max(0, Math.min(2, target - 4)) as Difficulty;
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, className = '', text = ''): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

function button(label: string, variant = ''): HTMLButtonElement {
  const b = el('button', variant, label);
  return b;
}

function waitClick(b: HTMLButtonElement): Promise<void> {
  return new Promise((resolve) => {
    const key = (e: KeyboardEvent): void => {
      if (e.code === 'Enter') {
        e.preventDefault();
        done();
      }
    };
    const done = (): void => {
      window.removeEventListener('keydown', key, true);
      b.removeEventListener('click', done);
      resolve();
    };
    b.addEventListener('click', done);
    window.addEventListener('keydown', key, true);
  });
}

let running = false;

export function minigameRunning(): boolean {
  return running;
}

/** Play the pending mini-game with real people. Resolves with the scores. */
export async function playMinigame(root: HTMLElement, state: GameState): Promise<MinigameResult> {
  running = true;
  try {
    return await run(root, state);
  } finally {
    running = false;
    root.classList.remove('open');
    root.replaceChildren();
  }
}

async function run(root: HTMLElement, state: GameState): Promise<MinigameResult> {
  const pending = state.pendingMinigame!;
  const pick = pickFor(state);
  const game: MiniGame = GAMES[pick.game];
  const difficulty = difficultyFor(state);
  const card: Card | undefined = pending.cardId ? state.cards[pending.cardId] : undefined;
  const pool = Object.values(state.cards);
  const me = current(state);
  const rivals = rivalsFor(state, pending.spec);
  const players: Player[] = [me, ...rivals];
  const duel = rivals.length > 0;
  const target = game.target(difficulty);
  const title = pick.theme?.title ?? (card ? card.title : game.title);

  root.classList.add('open');
  root.replaceChildren();
  const panel = el('div', 'mg-panel');
  root.append(panel);

  // --- intro ---
  const intro = (): void => {
    panel.replaceChildren();
    const head = el('div', 'mg-head');
    head.append(el('div', 'mg-icon', game.icon));
    const words = el('div');
    words.append(
      el('div', 'mg-kicker', pending.source === 'checkpoint' ? 'Checkpoint mini-game' : duel ? `Duel · ${game.title}` : `Mini-game · ${game.title}`),
      el('h2', 'mg-title', title),
    );
    head.append(words);
    panel.append(head);

    const body = el('div', 'mg-intro');
    if (card) {
      const mini = renderCard(card, 'mini');
      mini.classList.add('mg-card');
      body.append(mini);
    }
    const text = el('div', 'mg-intro-text');
    text.append(el('p', 'mg-how', game.how));
    if (duel) {
      text.append(el('p', 'mg-goal', `${players.map((p) => p.name).join(' vs ')} — everyone plays the same round. ${me.name} needs the best score to win the card.`));
    } else {
      text.append(
        el(
          'p',
          'mg-goal',
          pending.source === 'checkpoint'
            ? `Score ${target} ${game.unit} or more to earn the entry ticket.`
            : `Score ${target} ${game.unit} or more to collect this card.`,
        ),
      );
    }
    const chips = el('div', 'mg-players');
    for (const p of players) {
      const chip = el('span', 'mg-chip');
      const dot = el('span', 'swatch');
      dot.style.background = p.color;
      chip.append(dot, document.createTextNode(p.name));
      chips.append(chip);
    }
    text.append(chips);
    body.append(text);
    panel.append(body);
  };

  intro();
  const go = button(duel ? 'Start the duel' : "Let's play");
  const foot = el('div', 'mg-foot');
  foot.append(go);
  panel.append(foot);
  await waitClick(go);

  // --- each traveler plays ---
  const scores: { player: Player; score: number; summary: string }[] = [];
  for (let i = 0; i < players.length; i++) {
    const p = players[i];
    if (duel) {
      panel.replaceChildren();
      const ready = el('div', 'mg-ready');
      const dot = el('span', 'mg-ready-dot');
      dot.style.background = p.color;
      ready.append(dot, el('h2', '', `${p.name}, you're up`), el('p', '', i === 0 ? 'Show them how it’s done.' : `Score to beat: ${Math.max(...scores.map((s) => s.score))} ${game.unit}.`));
      const b = button(`Ready, ${p.name}!`);
      ready.append(b);
      panel.append(ready);
      await waitClick(b);
    }

    panel.replaceChildren();
    const top = el('div', 'mg-playing');
    const dot = el('span', 'swatch');
    dot.style.background = p.color;
    top.append(dot, document.createTextNode(`${p.name} · ${title}`));
    const stage = el('div', 'mg-stage');
    panel.append(top, stage);

    const result = await game.play(stage, {
      difficulty,
      playerName: p.name,
      playerColor: p.color,
      card,
      pool,
      theme: pick.theme ?? {},
      // Different rounds for each player, same across a replay of the action.
      seed: state.rngCursor * 31 + i * 977 + state.turn,
    });
    scores.push({ player: p, ...result });
    await new Promise((r) => setTimeout(r, 500));
  }

  // --- results ---
  const mine = scores[0];
  const passed = duel ? scores.slice(1).every((s) => mine.score >= s.score) : mine.score >= target;
  panel.replaceChildren();
  const res = el('div', `mg-result ${passed ? 'win' : 'lose'}`);
  res.append(el('div', 'mg-result-icon', passed ? '🏆' : '🙏'));
  res.append(
    el(
      'h2',
      '',
      duel
        ? passed
          ? `${me.name} wins the duel!`
          : `${[...scores].sort((a, b) => b.score - a.score)[0].player.name} wins the duel`
        : passed
          ? 'You did it!'
          : 'Not this time',
    ),
  );
  const table = el('div', 'mg-scores');
  for (const s of [...scores].sort((a, b) => b.score - a.score)) {
    const row = el('div', 'mg-score-row');
    const dot = el('span', 'swatch');
    dot.style.background = s.player.color;
    row.append(dot, el('span', 'mg-score-name', s.player.name), el('span', 'mg-score-sum', s.summary), el('b', '', `${s.score} ${game.unit}`));
    table.append(row);
  }
  res.append(table);
  if (!duel) res.append(el('p', 'mg-goal', `Needed ${target} ${game.unit}.`));
  const cont = button('Continue');
  res.append(cont);
  panel.append(res);
  await waitClick(cont);

  return {
    game: game.title,
    score: mine.score,
    passed,
    target: duel ? undefined : target,
    rivals: scores.slice(1).map((s) => ({ playerId: s.player.id, score: s.score })),
  };
}
